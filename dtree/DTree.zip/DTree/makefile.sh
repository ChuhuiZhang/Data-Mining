java -jar dtree.jar trainProdSelection.arff testProdSelection.arff trainProdIntro.binary.arff testProdIntro.binary.arff
