import weka.core.Instance;
import weka.core.Instances;

/**
 * @author Aswin
 * class contains variables and methods for facilitating development of the decision tree
 */
public class Brancher {
    /*
     * contains dataset associated with the particular node
     */
    private Instances data;
    /**
     * contains the index value of the node's attribute
     */
    private int index;
    /*
     * contains the number of possible values for the attribute (depends on whether the value is nominal or numeric)
     */
    private int numAttVals;
    /*
     * contains information regarding the counts of individual class values for each instance associated with this attribute
     * if nominal, create array of size data.instance(index).numValues
     * if numeric, split the values into 2 parts. Values lesser than a pivot element are stored in
     * classValCounter[0] or classValCounter[1]
     */
    private int[] classValCounter;
    /*
     * is nominal or numeric
     * nominal = true, numeric = false
     */
    private boolean isNominal = false;
    /*
     * contains the information gain associated with this attribute
     */
    private double infoGain;
    /*
     * if the attribute is numeric in nature, the pivot position is stored in this variable. If the attribute is norminal, the pivot
     * value will be -1;
     */
    private double pivot;
    /*
     * number of dataset class values
     */
    private int classValNum;
    /*
     * number of instance values
     */
    private int instanceSize;

    /**
     * Constructor
     * @param NodeData contains all the values of the dataset associated with the particular node
     * @param AttIndex contains the index of the attribute in the dataset
     */
    Brancher (Instances NodeData, int AttIndex) {
        this.data = NodeData;
        this.index = AttIndex;
        this.classValNum = data.classAttribute().numValues();
        //this.numAttVals = data.attribute(index).numValues();
        this.classValCounter = new int [classValNum];
        this.isNominal = data.attribute(index).isNominal();
        this.instanceSize = data.numInstances();

        int temp;
        for (int i = 0; i < instanceSize; i++) {
            temp = (int)data.instance(i).classValue();
            classValCounter[temp]++;
        }

        if (isNominal) {
            initializeNominal();
        } else {
            initializeNumeric();
        }
    }
    /**
     * @return the index
     */
    public int getIndex() {
        return index;
    }
    /**
     * @return the numAttVals
     */
    public int getNumAttVals() {
        return numAttVals;
    }
    /**
     * @return the classValCounter
     */
    public int[] getClassValCounter() {
        return classValCounter;
    }
    /**
     * @return the isNominal
     */
    public boolean isNominal() {
        return isNominal;
    }
    /**
     * @return the infoGain
     */
    public double getInfoGain() {
        return infoGain;
    }
    /**
     * @return the pivot
     */
    public double getPivot() {
        return pivot;
    }
    /**
     * @return the instanceSize
     */
    public int getInstanceSize() {
        return instanceSize;
    }
    /**
     * initialization method for attributes with nominal values
     */
    private void initializeNominal() {
        numAttVals = data.attribute(index).numValues();
        pivot = -1;
        infoGain = InfogainCalculator.infoGainNominalCalculator(classValNum, classValCounter, index, data, instanceSize, numAttVals);
    }
    /**
     * initialization method for attributes with numeric values
     */
    private void initializeNumeric() {
        numAttVals = 2;
        double[] minMaxRange = MiscFunctions.rangeFinder(data, index);
        double[] infoGainPivot = new double[2];
        infoGainPivot = InfogainCalculator.infoGainNumericCalculator(classValNum, classValCounter, index, data, instanceSize, numAttVals,
                minMaxRange[0], minMaxRange[1], minMaxRange[2], 10);
        infoGain = infoGainPivot[0];
        pivot = infoGainPivot[1];
    }
    /**
     * Method for creating the childnodes for an attribute node in the decision tree
     * @param data
     * @return children
     */
    public Instances[] createChildNodes(Instances data) {
        Instances[] children = new Instances[numAttVals];
        //creating empty set of instances
        for (int i = 0; i < numAttVals; i++) {
            children[i] = new Instances(data, instanceSize);
        }
        //classifying the various instances based on the value of the selected attribute
        for (int i = 0; i < instanceSize; i++) {
            Instance temp = data.instance(i);
            if (isNominal) {
                children[(int)temp.value(index)].add(temp);
            } else {
                if (data.instance(i).value(index) < pivot) {
                    children[0].add(temp);
                } else {
                    children[1].add(temp);
                }
            }
        }
        return children;
    }
    /**
     * Find out whether the value of a numeric attribute is below or above the pivot value
     * @param datum
     * @param childNodes
     * @return
     */
    public DTNode getNumericPosition(Instance datum, DTNode[] childNodes ) {
        if (datum.value(index) < pivot) {
            return childNodes[0];
        } else {
            return childNodes[1];
        }
    }
}
