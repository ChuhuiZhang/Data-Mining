import java.text.DecimalFormat;

import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
/**
 * class for building the decision tree
 * @author Aswin
 *
 */
public class DTree {
    private DTNode root;       // root of dtree
    private Instances data;    // the original train data
    Instances validationDataSet;
    /**
     * constructor for the decision tree
     * @param inst
     */
    DTree(Instances inst) {
        this.data = inst;
        root = new DTNode(data);
        validationDataSet = null;
    }
    /**
     * Using this function, we can find out which set of data are the best for training the decision tree model. The dataset is split
     * into two parts, one for training and the other cross validation with the trained model. The training data which gives the
     * highest accuracy during cross validation is used to predict the output of the test dataset.
     * @param dataSet
     * @param num
     * @return
     */
    public DTree optimalDataSetSelector(Instances dataSet, int num){
        Instances[] section = MiscFunctions.crossValidationGrouper(dataSet, num);
        //calculate accuracy for individual groups
        double accuracyForSection[] = new double[num];
        double correctValue = 0;
        double accuracyRatio = 0;
        DTree bestTree = null;
        int testIndex = 0;
        double bestAccuracy = 0;
        for(int i = 0;i < num; i++) {
            Instances testingSet = section[i];
            Instances trainingDataSet= MiscFunctions.createTrainingData(dataSet, section, i, num);
            DTree treeTester = new DTree(trainingDataSet);
            correctValue = MiscFunctions.correctnessCalculator(testingSet, treeTester);
            accuracyRatio = correctValue / testingSet.size();
            accuracyForSection[i] = accuracyForSection[i] + accuracyRatio;
            if (bestAccuracy < accuracyRatio && accuracyRatio != 1) {
                bestAccuracy = accuracyRatio;
                testIndex = i;
                bestTree = treeTester;
                bestTree.validationDataSet = testingSet;
            }
        }
        //MiscFunctions.accuracyPrinter(accuracyForSection);
        System.out.println();
        System.out.println("DataSet used for training:");
        MiscFunctions.displayTrainingData(testIndex, section);
        System.out.println();
        System.out.println();
        return bestTree;
    }
    /**
     * Getter for root of the tree
     * @return
     */
    public DTNode getRoot(){
        return root;
    }
    /**
     * A function to set the output of the class of the test dataset
     * @param data
     */
    public void outputSetter(Instance data) {
        int output = root.classCategorization(data);
        data.setClassValue(output);
    }
    /**
     * Function to perform cross validation
     */
    public void crossValidationFunction() {
        double correctValue = MiscFunctions.correctnessCalculator(this.validationDataSet, this);
        double accuracy = correctValue / this.validationDataSet.size();
        DecimalFormat df = new DecimalFormat("#.00");
        System.out.println("The approximate accuracy of the model based on cross-validation test is " + df.format(accuracy * 100) + "%");
    }

    public void displayOutput(Instances data) {
        System.out.println("Displaying decision tree structure");
        System.out.println();
        MiscFunctions.displayTree(data, root, 0);
    }

    // display the tree node

    /**
     * main function
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {

        //////////////////////////////////////////PRODUCT A/////////////////////////////////

        System.out.println("**************************Product A***************************");
        //standard code to import data from the file
        DataSource productATrain = new DataSource("trainProdSelection.arff");
        Instances trainingData = productATrain.getDataSet();
        //make last attribute column as class
        if(trainingData.classIndex()==-1) {
            trainingData.setClassIndex(trainingData.numAttributes()-1);
        }

        System.out.println();
        System.out.println("**********Building Decision Tree using ID3 algorithm**********");
        DTree decisionTreeProductA = new DTree(trainingData);
        System.out.println("******************Successfully Completed**********************");
        System.out.println("**************************************************************");


        decisionTreeProductA = decisionTreeProductA.optimalDataSetSelector(trainingData, 20);
        decisionTreeProductA.displayOutput(trainingData);
        System.out.println("*****************Performing Cross Validation******************");
        System.out.println();
        decisionTreeProductA.crossValidationFunction();
        System.out.println();


        System.out.println("***************Predicting output for new dataset**************");
        System.out.println();


        DataSource productATest = new DataSource("testProdSelection.arff");
        Instances testingData = productATest.getDataSet();
        if (testingData.classIndex() == -1) testingData.setClassIndex(testingData.numAttributes() - 1);
        MiscFunctions.displayer(decisionTreeProductA, testingData);

        System.out.println();
        System.out.println();

        ////////////////////////////////////PRODUCT B//////////////////////////////////////

        System.out.println("**************************Product B***************************");
        DataSource productBTrain = new DataSource("trainProdIntro.binary.arff");
        Instances trainingData2 = productBTrain.getDataSet();
        if(trainingData2.classIndex()==-1) {
            trainingData2.setClassIndex(trainingData2.numAttributes()-1);
        }
        System.out.println();
        System.out.println("**********Building Decision Tree using ID3 algorithm**********");
        DTree decisionTreeProductB = new DTree(trainingData2);
        System.out.println("******************Successfully Completed**********************");
        System.out.println("**************************************************************");


        decisionTreeProductB = decisionTreeProductB.optimalDataSetSelector(trainingData2, 10);
        decisionTreeProductB.displayOutput(trainingData2);
        System.out.println("*****************Performing Cross Validation******************");
        System.out.println();
        decisionTreeProductB.crossValidationFunction();
        System.out.println();


        System.out.println("***************Predicting output for new dataset**************");
        System.out.println();
        DataSource productBTest = new DataSource("testProdIntro.binary.arff");
        Instances testingData2 = productBTest.getDataSet();
        if (testingData2.classIndex() == -1) testingData2.setClassIndex(testingData2.numAttributes() - 1);
        MiscFunctions.displayer(decisionTreeProductB, testingData2);

    }
}
