import java.text.DecimalFormat;
import java.util.Random;

import weka.core.Attribute;
import weka.core.Instances;

/**
 *
 * @author Aswin Class contains misc. funtions for creating the decision tree
 *
 */
public class MiscFunctions {

	/**
	 * function to calculate the minmum and maximum values in a numeric attribute
	 * 
	 * @param data
	 * @param index
	 * @return
	 */
	public static double[] rangeFinder(Instances data, int index) {
		double[] minMax = new double[3];
		double minValue = data.instance(0).value(index);
		double maxValue = data.instance(0).value(index);
		int size = data.size();
		double checkValue;
		for (int i = 0; i < size; i++) {
			checkValue = data.instance(i).value(index);
			if (checkValue < minValue) {
				minValue = checkValue;
			}
			if (checkValue > maxValue) {
				maxValue = checkValue;
			}
		}
		minMax[0] = minValue;
		minMax[1] = maxValue;
		minMax[2] = maxValue - minValue;// range of values of the numeric attribute
		return minMax;
	}

	private static void slashDisplayer(int range) {
		for (int i = 0; i < range; i++) {
			System.out.print(" | ");
		}
	}

	/**
	 * Helper function to calculate mean accuracy
	 * 
	 * @param accuracyArray
	 * @return
	 */
	public static double accuracyCalculator(double[] accuracyArray) {
		double accuracy = 0;
		for (int i = 0; i < accuracyArray.length; i++) {
			accuracy = accuracy + accuracyArray[i];
		}
		return accuracy / accuracyArray.length;
	}

	/**
	 * Helper function to calculate max accuracy
	 * 
	 * @param accuracyArray
	 * @return
	 */
	public static double accuracyMaxCalculator(double[] accuracyArray) {
		double accuracy = 0;
		for (int i = 0; i < accuracyArray.length; i++) {
			// if (accuracyArray[i] == 1.0) {
			// accuracyArray[i] = 0.9;
			// }
			if (accuracyArray[i] > accuracy && accuracyArray[i] != 1.0) {
				accuracy = accuracyArray[i];
			}
		}
		return accuracy;
	}

	/**
	 * Helper function to retrieve the index for dataSet used for testing during
	 * cross validation
	 * 
	 * @param accuracyArray
	 * @return
	 */
	public static int accuracyMaxIndex(double[] accuracyArray) {
		double accuracy = 0;
		int index = 0;
		for (int i = 0; i < accuracyArray.length; i++) {
			if (accuracyArray[i] == 1.0) {
				accuracyArray[i] = 0.9;
			}
			if (accuracyArray[i] > accuracy) {
				accuracy = accuracyArray[i];
				index = i;
			}
		}
		return index;
	}

	/**
	 * Helper function used for displaying the accuracy of all the test dataSets
	 * used for cross validation
	 * 
	 * @param accuracyArray
	 */

	public static void accuracyPrinter(double[] accuracyArray) {
		DecimalFormat df = new DecimalFormat("0.00");
		for (int i = 0; i < accuracyArray.length; i++) {
			System.out.println("Test " + i
			    + ": Training Decision Tree using dataSet " + i
			    + " and validating accuracy: " + df.format(accuracyArray[i]));
		}
	}

	/**
	 * Helper function used for getting the value of log base 2 of x
	 * 
	 * @param x
	 * @return
	 */
	public static double logBase2(double x) {
		return (Math.log(x) / Math.log(2));
	}

	/**
	 * Helper function used for calculating pivot positin's value for numeric
	 * attributes
	 * 
	 * @param minValue
	 * @param range
	 * @param frequency
	 * @param skip
	 * @return
	 */
	public static double newPivotPos(double minValue, double range,
	    double frequency, int skip) {
		return minValue + (range / frequency) * (skip + 1);
	}

	/**
	 * Helper function to decide if a numeric attribute's value is below or above
	 * the pivot value
	 * 
	 * @param data
	 * @param i
	 * @param index
	 * @param currPivot
	 * @return
	 */
	public static int calculateAttVal(Instances data, int i, int index,
	    double currPivot) {
		if (data.instance(i).value(index) < currPivot) {
			return 0;
		} else {
			return 1;
		}
	}

	/**
	 * Function to validate node for display function
	 * 
	 * @param node
	 * @param range
	 * @param data
	 * @return
	 */
	private static boolean validateNode(DTNode node, int range, Instances data) {
		if (node == null) {
			return false;
		}
		MiscFunctions.slashDisplayer(range);
		if (node.isLeafNode()) {
			System.out.println("reached leaf node-->"
			    + data.classAttribute().value(node.getMaxClassIndex()));
			return false;
		}
		return true;
	}

	/**
	 * Helper function to group data for cross validation process
	 * 
	 * @param dataSet
	 * @param num
	 * @return
	 */
	public static Instances[] crossValidationGrouper(Instances dataSet, int num) {
		Instances[] section = new Instances[num];
		// instantiating the "Instances" array
		for (int i = 0; i < num; i++) {
			section[i] = new Instances(dataSet, dataSet.size());
		}
		// radomizing the position of the dataSet
		Random randomizer = new Random(System.currentTimeMillis());
		dataSet.randomize(randomizer);
		// spliting the data into sections for cross Validation
		int sectionNumber = 0;
		int divident = dataSet.numInstances() / num;
		for (int i = 0; i < dataSet.size() - dataSet.numInstances() % num; i++) {
			sectionNumber = i / divident;
			section[sectionNumber].add(dataSet.get(i));
		}
		return section;
	}

	/**
	 * display the output of attributes that are numeric
	 * 
	 * @param range
	 * @param node
	 * @param brancher
	 * @param data
	 * @param side
	 */
	private static void displayNodeNumeric(int range, DTNode node,
	    Brancher brancher, Instances data, int side) {
		MiscFunctions.slashDisplayer(range + 1);
		if (side == 0) {
			System.out.println("<" + brancher.getPivot() + "-->");
		} else {
			System.out.println(">" + brancher.getPivot() + "-->");
		}
		displayTree(data, node.getChildren()[side], range + 2);
	}

	/**
	 * display the output of attributes that are nominal
	 * 
	 * @param range
	 * @param att
	 * @param node
	 * @param numOfAttValues
	 * @param in
	 */
	private static void displayNodeNominal(int range, Attribute att, DTNode node,
	    int numOfAttValues, Instances in) {
		int size = 0;
		while (size < numOfAttValues) {
			MiscFunctions.slashDisplayer(range + 1);
			System.out.println(att.value(size) + "-->");
			displayTree(in, node.getChildren()[size], range + 2);
			size++;
		}
	}

	/**
	 * Helper function to display the dataSet used for training the decision tree
	 * 
	 * @param index
	 * @param section
	 */
	public static void displayTrainingData(int index, Instances[] section) {
		int nav = 0;
		while (nav < section.length) {
			if (nav != index) {
				for (int i = 0; i < section[nav].numInstances(); i++) {
					System.out.println(section[nav].get(i));
				}
				// System.out.println(section[nav]);
			}
			nav++;
		}
	}

	public static Instances createTrainingData(Instances dataSet,
	    Instances[] section, int index, int num) {
		Instances trainingDataSet = new Instances(dataSet, dataSet.size());
		int nav = 0;
		while (nav < num) {
			if (nav != index) {
				trainingDataSet.addAll(section[nav]);
			}
			nav++;
		}
		// System.out.println("The size of training dataSet is " +
		// trainingDataSet.size());
		return trainingDataSet;
	}

	/**
	 * Helper function to calculate the number correct predictions during cross
	 * validation
	 * 
	 * @param testingSet
	 * @param treeTester
	 * @return
	 */
	public static double correctnessCalculator(Instances testingSet,
	    DTree treeTester) {
		double correctnessValue = 0;
		int nav = 0;
		int predictedClassValue = 0;
		int actualClassValue = 0;
		DTNode temp = treeTester.getRoot();
		while (nav < testingSet.size()) {
			predictedClassValue = temp.classCategorization(testingSet.get(nav));
			actualClassValue = (int) testingSet.get(nav).classValue();
			if (predictedClassValue == actualClassValue) {
				correctnessValue++;
			}
			nav++;
		}
		return correctnessValue;
	}

	/**
	 * Helper function to predict and display the output of the test dataSet.
	 * 
	 * @param dt
	 * @param ins
	 */
	public static void displayer(DTree dt, Instances ins) {
		int i = 0;
		while (i < ins.numInstances()) {
			dt.outputSetter(ins.instance(i));
			System.out.println(ins.get(i));
			i++;
		}

	}

	/**
	 * Function to display the tree
	 * 
	 * @param data
	 * @param node
	 * @param range
	 */
	public static void displayTree(Instances data, DTNode node, int range) {
		if (!validateNode(node, range, data)) {
			return;
		}
		int index = node.getBrancher().getIndex();
		Attribute attribute = data.attribute(index);
		int numOfAttValues = node.getBrancher().getNumAttVals();
		if (attribute.isNominal()) {
			System.out.println(attribute.name().toUpperCase());
			displayNodeNominal(range, attribute, node, numOfAttValues, data);
		} else {
			System.out.println(attribute.name().toUpperCase());
			displayNodeNumeric(range, node, node.getBrancher(), data, 0);
			displayNodeNumeric(range, node, node.getBrancher(), data, 1);
		}
	}

}
