import weka.core.Instances;

/**
 *
 * @author Aswin
 * class for performing operations related to specific entropy and information gain calculation
 *
 */
public class InfogainCalculator {
    /**
     * Helper Function to calculate information gain if the attribute value is nominal
     * @param classValNum
     * @param classValCounter
     * @param index
     * @param data
     * @param instanceSize
     * @param numAttVals
     * @return
     */
    public static double infoGainNominalCalculator(int classValNum, int[] classValCounter, int index, Instances data,
            int instanceSize, int numAttVals) {
        double classEntropy = classEntropy(classValNum, classValCounter, data, instanceSize);
        double conditionalEntropy = conditionalEntropy(classValNum, classValCounter, data, instanceSize, numAttVals, index);
        return classEntropy - conditionalEntropy;
    }
    /**
     * Helper function to calculate information gain if the attribute value is numeric
     * @param classValNum
     * @param classValCounter
     * @param index
     * @param data
     * @param instanceSize
     * @param numAttVals
     * @param minValue
     * @param maxValue
     * @param range
     * @param frequency
     * @return
     */
    public static double[] infoGainNumericCalculator(int classValNum, int[] classValCounter, int index, Instances data,
            int instanceSize, int numAttVals, double minValue, double maxValue, double range, int frequency) {

        double[] infoGainPivot = new double[2];

        double classEntropy = classEntropy(classValNum, classValCounter, data, instanceSize);
        double[] conditionalEntropy = conditionalEntropyNum(classValNum, classValCounter, data, instanceSize, numAttVals, index,
                minValue, maxValue, range, frequency);
        infoGainPivot[0] = classEntropy - conditionalEntropy[0];//information gain
        infoGainPivot[1] = conditionalEntropy[1];//pivot value
        return infoGainPivot;
    }
    /**
     * Helper function to calculate H(Y)
     * @param classValNum
     * @param classValCounter
     * @param data
     * @param instanceSize
     * @return
     */
    private static double classEntropy(int classValNum, int[] classValCounter, Instances data, int instanceSize) {
        double classEntropy = 0.0;
        double probability;
        for (int i = 0; i < classValNum; i++) {
            probability = 0.0;
            if (classValCounter[i] > 0) {
                probability = (double)classValCounter[i]/instanceSize;
                classEntropy = classEntropy - probability*(MiscFunctions.logBase2(probability));
            }
        }
        return classEntropy;
    }
    /**
     * Helper function to calculate H(Y|X) if the attribute is nominal
     * @param classValNum
     * @param classValCounter
     * @param data
     * @param instanceSize
     * @param numAttVals
     * @param index
     * @return
     */
    private static double conditionalEntropy(int classValNum, int[] classValCounter, Instances data, int instanceSize,
            int numAttVals, int index) {
        double conditionalEntropy = 0;
        double[] attCounter = new double[numAttVals];
        double[][] attClassCounter = new double[numAttVals][classValNum];

        //To find out P(Y|X) you have to know the individual quantities of Y and X
        int attVal;
        int classVal;
        for (int i = 0; i < instanceSize; i++) {
            attVal = (int)data.instance(i).value(index);
            classVal = (int)data.instance(i).classValue();
            attCounter[attVal]++;
            attClassCounter[attVal][classVal]++;
        }
        //performing calculations
        double temp = 0;
        double pConditional;
        double p;
        for(int i=0; i < attClassCounter.length; i++){
            if(attCounter[i] > 0){
                for(int j = 0; j < attClassCounter[0].length; j++){
                    if(attClassCounter[i][j] > 0){
                        pConditional = attClassCounter[i][j] / attCounter[i];
                        temp = temp - pConditional * MiscFunctions.logBase2(pConditional);
                    }
                }
                p = attCounter[i] / instanceSize;
                conditionalEntropy = conditionalEntropy + temp * p;
                temp = 0;
            }
        }
        return conditionalEntropy;
    }
    /**
     * Helper function to calculate H(Y|X) if attribute is numeric
     * @param classValNum
     * @param classValCounter
     * @param data
     * @param instanceSize
     * @param numAttVals
     * @param index
     * @param minValue
     * @param maxValue
     * @param range
     * @param frequency
     * @return
     */
    private static double[] conditionalEntropyNum(int classValNum, int[] classValCounter, Instances data, int instanceSize,
            int numAttVals, int index, double minValue, double maxValue, double range, int frequency) {
        double[] condtionalEntropyVal = new double[2];

        double conditionalEntropy = 0;
        double pivotValue = 0;
        double[] attCounter = new double[numAttVals];
        double[][] attClassCounter = new double[numAttVals][classValNum];
        double minCP = Double.MAX_VALUE;

        double currPivot = minValue;
        double currCP = 0.0;

        //calculating which pivot position gives minimum conditionEntropy, so that I.G = H(Y) - H(Y|X) is maximum
        int skipper = 0;
        while (skipper < frequency - 1) {
            currPivot = MiscFunctions.newPivotPos(minValue, range, frequency, skipper);
            for (int i = 0; i < instanceSize; i++) {
                int attVal = MiscFunctions.calculateAttVal(data, i, index, currPivot);
                int classVal = (int)data.instance(i).classValue();
                attCounter[attVal]++;
                attClassCounter[attVal][classVal]++;
            }

            double temp = 0;
            double pConditional;
            double p;
            currCP = 0.0;
            for(int i=0; i < attClassCounter.length; i++){
                if(attCounter[i] > 0){
                    for(int j = 0; j < attClassCounter[0].length; j++){
                        if(attClassCounter[i][j] > 0){
                            pConditional = attClassCounter[i][j] / attCounter[i];
                            temp = temp - pConditional * MiscFunctions.logBase2(pConditional);
                        }
                    }
                    p = attCounter[i] / instanceSize;
                    currCP = conditionalEntropy + temp * p;
                    temp = 0;
                }
            }

            if ( minCP > currCP) {
                minCP = currCP;
                pivotValue = currPivot;
            }
            skipper++;
        }
        conditionalEntropy = minCP;
        condtionalEntropyVal[0] = conditionalEntropy;
        condtionalEntropyVal[1] = pivotValue;
        return condtionalEntropyVal;
    }
}
