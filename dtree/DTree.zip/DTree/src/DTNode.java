import java.util.Arrays;

import weka.core.Instance;
import weka.core.Instances;

/**
 *
 * @author Aswin
 * class that contains related to individual nodes of the decision tree
 *
 */
public class DTNode {
    private static final int minClassDifference = 0;
    private static final int minNoOfInstances = 2;
    private static final int minAttributeNum = 0;
    /*
     * contains details regarding the nodes children
     */
    private DTNode[] childNodes;
    /*
     * contains information regarding the counts of individual class values for each instance associated with this attribute
     */
    private int[] classValCounter;
    /**
     * contains methods for information gain calculation and tree node branching
     */
    private Brancher brancher;
    /*
     * number of dataset class values
     */
    private int classValNum;
    /*
     * number of instance values
     */
    private int instanceSize;
    /*
     * contains dataset associated with the particular node
     */
    private Instances data;
    /*
     * max class index
     */
    private int maxClassIndex = 0;
    /*
     * is the current node a leaf node?
     */
    private boolean leafNode = false;
    /**
     * constructor for the Decision Tree Node
     * @param dataSet
     */
    DTNode(Instances dataSet) {
        this.data = dataSet;
        this.classValNum = data.classAttribute().numValues();
        this.classValCounter = new int [classValNum];
        this.instanceSize = data.numInstances();
        int temp;
        for (int i = 0; i < instanceSize; i++) {
            temp = (int)data.instance(i).classValue();
            classValCounter[temp]++;
        }
        createTree();
    }
    /**
     * function to build the decision tree
     */
    public void createTree() {
        if (finalResult()) {
            leafNode = true;
            maxClassIndex = getMaxClassIndex();
            return;//stop recursive tree creation
        }
        double maxGainValue = Double.MIN_VALUE;
        for (int i = 0; i < data.numAttributes() - 1; i++) {
            Brancher temp = new Brancher(data, i);
            if (temp.getInfoGain() > maxGainValue) {
                maxGainValue = temp.getInfoGain();
                brancher = temp;
            }
        }

        if (preliminaryValidation(brancher)) {
            return;//stop recursive tree creation
        }
        Instances[] attributeValues = brancher.createChildNodes(data);
        //MiscFunctions.displayChildNodes(this, data);
        int childLength = attributeValues.length;
        childNodes = new DTNode[childLength];
        for (int i = 0; i < childLength; i++) {
            childNodes[i] = new DTNode(attributeValues[i]);
        }
    }
    private boolean preliminaryValidation(Brancher brancher) {
        if (brancher == null) {
            leafNode = true;
            maxClassIndex = getMaxClassIndex();
            return true;
        }
        return false;
    }
    /**
     * Helper function to classify a data instance based on its output
     * @param datum
     * @return
     */
    public int classCategorization(Instance datum) {
        if (isLeafNode()) {
            return maxClassIndex;
        }
        DTNode child;
        if (brancher.isNominal()) {
            child = childNodes[(int)datum.value(brancher.getIndex())];
        } else {
            child = brancher.getNumericPosition(datum, childNodes);
        }
        return child.classCategorization(datum);
    }
    /**
     * Helper function that helps to decide if a node in the decision tree should be expanded further.
     * Conditions for stopping tree expansion:
     * 1) (ClassOutput1, ClassOutput2) = (n, 0)
     * 2) number of instances remaining < minNoOfInstances
     * 3) if (ClassOutput1, ClassOutput2) = (n, m) && absolute value of n - m <= minClassDifference
     * @return
     */
    private boolean finalResult() {
        int[] arrayTemp = new int[classValCounter.length];
        System.arraycopy(classValCounter, 0, arrayTemp, 0, classValCounter.length);
        Arrays.sort(arrayTemp);
        if (arrayTemp[classValNum - 1] >= instanceSize - minClassDifference) {
            return true;
        }
        if (data.numAttributes() <= minAttributeNum) {
            return true;
        }
        if (data.numInstances() < minNoOfInstances) {
            return true;
        }
        return false;
    }
    public int getMaxClassIndex() {
        int maxIndex = 0;
        for (int i = 0; i < classValNum; i++) {
            if (classValCounter[maxIndex] < classValCounter[i]) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }
    /**
     * check if current node is a leaf node
     * @return boolean
     */
    public boolean isLeafNode() {
        return leafNode;
    }
    public DTNode[] getChildren() {
        return childNodes;
    }
    public int getIndex() {
        return maxClassIndex;
    }
    public Brancher getBrancher() {
        return brancher;
    }
}
